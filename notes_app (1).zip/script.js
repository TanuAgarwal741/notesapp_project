let notes = [];
let editIndex = null;

document.addEventListener("DOMContentLoaded", () => {
  const localData = localStorage.getItem("notes");

  if (localData) {
    notes = JSON.parse(localData);
  } else {
    notes = [
      {
        id: 1,
        title: "Meeting Notes",
        description: "Discussion about project milestones",
        category: "Work",
        createdAt: new Date().toLocaleString()
      }
    ];
    saveToLocal();
  }

  displayNotes();
});

function openModal() {
  document.getElementById("noteModal").style.display = "block";
}

function closeModal() {
  document.getElementById("noteModal").style.display = "none";
  editIndex = null;
}

function saveNote() {
  const title = document.getElementById("noteTitle").value;
  const desc = document.getElementById("noteDesc").value;
  const category = document.getElementById("noteCategory").value;

  if (!title.trim()) {
    alert("Title cannot be empty");
    return;
  }

  if (editIndex !== null) {
    notes[editIndex].title = title;
    notes[editIndex].description = desc;
    notes[editIndex].category = category;
  } else {
    notes.push({
      id: Date.now(),
      title,
      description: desc,
      category,
      createdAt: new Date().toLocaleString()
    });
  }

  saveToLocal();
  displayNotes();
  closeModal();
}

function displayNotes(filter = "All") {
  const container = document.getElementById("notesContainer");
  container.innerHTML = "";

  const filtered = filter === "All"
    ? notes
    : notes.filter(n => n.category === filter);

  filtered.forEach((note, index) => {
    const card = document.createElement("div");
    card.className = "note-card";

    card.innerHTML = `
      <h3>${note.title}</h3>
      <p>${note.description}</p>
      <small>${note.category} | ${note.createdAt}</small><br><br>
      <button onclick="editNote(${index})">Edit</button>
      <button onclick="deleteNote(${index})">Delete</button>
    `;

    container.appendChild(card);
  });
}

function editNote(index) {
  editIndex = index;
  const note = notes[index];

  document.getElementById("noteTitle").value = note.title;
  document.getElementById("noteDesc").value = note.description;
  document.getElementById("noteCategory").value = note.category;

  openModal();
}

function deleteNote(index) {
  if (confirm("Delete this note?")) {
    notes.splice(index, 1);
    saveToLocal();
    displayNotes();
  }
}

function saveToLocal() {
  localStorage.setItem("notes", JSON.stringify(notes));
}

function filterNotes(category) {
  displayNotes(category);
}